PhysicsObject =
{
	x = -32,
	y = 0,
	bodyType = 0,
	fixtureList =
	{
		Wall =
		{
			w = 32,
			h = 576,
			angle = 0,
			density = 1,
			friction = 1,
			restitution = 0,
			collisionType = 0x0002,
			collidesWith =
			{
				[0] = 0x0001
			},
			fixedRotation = true
		}
	}
}