entity =
{
	special = true,
	name = "stickman",
	TransformComponent =
	{
		x = 200,
		y = 200,
		width = 64,
		height = 205,
		angle = 0.0
	},
	SpriteComponent =
	{
		spriteName = "playerWalkFrame1",
		layer = 1
	},
	RenderableComponent = 
	{
	},
	AnimationComponent =
	{
		paused = false,
		defaultAnim = "walking",
		Animations =
		{
			walking =
			{
				looped = true,
				speed = 1.0,
				timePerFrame = 100,
				totalFrames = 4,
				frames = 
				{
					[0] = "playerWalkFrame1",
					[1] = "playerWalkFrame2",
					[2] = "playerWalkFrame3",
					[3] = "playerWalkFrame4"
				}
			}	
		}
	}
}