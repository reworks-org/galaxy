world =
{
	entitys =
	{
		[0] = "scripts/test.lua",
		[1] = "scripts/stickman.lua",
		[2] = "scripts/ground.lua"
	}
}