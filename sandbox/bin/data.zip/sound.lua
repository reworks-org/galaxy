sounds =
{
	space =
	{
		file = "beep.wav",
		pan = 0.0,
		speed = 1.0,
		volume = 1.0
	}
}