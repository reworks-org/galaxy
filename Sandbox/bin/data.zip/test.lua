entity =
{
	special = true,
	name = "test",
	TransformComponent =
	{
		x = 0,
		y = 0,
		width = 1280,
		height = 720,
		angle = 0.0
	},
	TextComponent =
	{
		text = "TEST!!!",
		font = "GameOver18",
		colour =
		{
			r = 255,
			g = 255,
			b = 255, 
			a = 255
		},
		offsetX = 0,
		offsetY = 0,
		layer = 1
	},
	SpriteComponent =
	{
		spriteName = "background",
		layer = 0
	},
	RenderableComponent =
	{
	}
}