world =
{
	entitys =
	{
		[0] = "test.lua",
		[1] = "stickman.lua"
	}
}