world =
{
	entitys =
	{
		[0] = "test.lua",
		[1] = "stickman.lua",
		[2] = "ground.lua"
	}
}