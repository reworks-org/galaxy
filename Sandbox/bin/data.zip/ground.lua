entity =
{
	special = true,
	name = "ground",
	TransformComponent =
	{
		x = 100,
		y = 600,
		width = 300,
		height = 50,
		angle = 0.0
	},
	SpriteComponent =
	{
		spriteName = "ground",
		layer = 1
	},
	RenderableComponent = 
	{
	},
	PhysicsComponent = 
	{
		x = 100,
		y = 600,
		bodyType = 0,
		fixedRotation = true,
		fixtureList =
		{
			fixtureA = 
			{
				w = 300,
				h = 50,
				angle = 0.0,
				density = 1,
				friction = 50,
				restitution = 0,
				id = "ground"
			}
		}
	}
}