fonts =
{
	GameOver18 =
	{
		font = "game_over.ttf",
		size = 18
	},
	SecretCode37 =
	{
		font = "sercode.ttf",
		size = 37
	}
}