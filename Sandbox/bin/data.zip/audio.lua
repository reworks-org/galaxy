audio =
{
	background =
	{
		type = "music",
		file = "PleasingGuns.ogg",
		playmode = 1,
		pan = 0.0,
		speed = 1.0,
		volume = 0.5
	},
	space =
	{
		type = "sound",
		file = "beep.wav",
		pan = 0.0,
		speed = 1.0,
		volume = 1.0
	}
}