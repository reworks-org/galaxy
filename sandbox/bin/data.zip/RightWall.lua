PhysicsObject =
{
	x = 1280,
	y = 0,
	bodyType = 0,
	fixtureList =
	{
		w = 32,
		h = 1312,
		angle = 0,
		density = 1,
		friction = 1,
		restitution = 0,
		collisionType = 0x0002,
		collidesWith =
		{
			[0] = 0x0001
		},
		fixedRotation = true
	}
}