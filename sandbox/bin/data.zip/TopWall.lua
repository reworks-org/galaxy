PhysicsObject =
{
	x = -32,
	y = -32,
	bodyType = 0,
	fixtureList =
	{
		w = 1344,
		h = 32,
		angle = 0,
		density = 1,
		friction = 1,
		restitution = 0,
		collisionType = 0x0002,
		collidesWith =
		{
			[0] = 0x0001
		},
		fixedRotation = true
	}
}