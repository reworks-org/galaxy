fonts =
{
	GameOver18 =
	{
		font = "game_over.ttf",
		size = 18
	}
}